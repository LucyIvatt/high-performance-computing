#ifndef BOUNDARY_H
#define BOUNDARY_H

void apply_boundary_conditions();

#endif